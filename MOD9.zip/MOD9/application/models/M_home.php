<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Home extends CI_Model {

    public function cekloginPembaca($username,$password) {
        $this->db->select('*');
        $this->db->from('pembaca'); //bisa penulis???
        $this->db->where('usernamePembaca',$username);
        $this->db->where('password',$password);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function cekloginPenulis($username,$password) {
        $this->db->select('*');
        $this->db->from('penulis'); //bisa penulis???
        $this->db->where('usernamePenulis',$username);
        $this->db->where('password',$password);
        $query = $this->db->get();
        return $query->num_rows();
    }


    public function getPenulis($uname,$email) {
        $this->db->select('*');
        $this->db->from('penulis');
        $this->db->where('usernamePenulis',$uname)->or_where('emailPenulis',$email);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function tambahPenulis() {
		$data = [    	
        	'usernamePenulis' => $this->input->post('uname',true),
            'password' => $this->input->post('pass',true),
        	'emailPenulis' => $this->input->post('email',true),
        	'tglLahir' => $this->input->post('tanggal',true),
        	//'keterangan' => 'penulis'
    	];
    	$this->db->insert('penulis',$data);
    }
}