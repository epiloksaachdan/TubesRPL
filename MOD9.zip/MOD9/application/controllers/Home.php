<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('M_Home');
		$this->load->library('form_validation');
	}

	public function index() {
		$this->load->view('user/page_header');
		$this->load->view('user/page_index');
	}

	public function login() {
		$username = $this->input->post("username");
        $password = $this->input->post("password");
        //die($password);
        $cek1 = $this->M_Home->cekloginPembaca($username, $password);
        $cek2 = $this->M_Home->cekloginPenulis($username, $password);
        if ($cek1 == 1 AND $cek2 == 0) { //masuk ke pembaca
            $data_session = array(
                'nama' => $username,
                'status' => "login"
            );
            $this->session->set_userdata($data_session);
            redirect('index.php/Home/setelahloginpembaca');
        } else if ($cek1 == 0 AND $cek2 == 1) { //masuk ke penulis
            $data_session = array(
                'nama' => $username,
                'status' => "login"
            );  
            $this->session->set_userdata($data_session);
            redirect('index.php/Home/setelahloginpenulis');
        } else {
            echo '<script type="text/javascript">
                alert("Maaf Username/Password Anda Salah");
            </script>';
            $this->load->view('user/page_header');
            $this->load->view('user/page_index');
        }
	}

    public function setelahloginpenulis() {
        $uname = $this->session->userdata("nama");
        $databuku = $this->M_Home->getBukuPenulis($uname);
        $this->load->view('user/penulis/page_headerLoginPenulis');
        $this->load->view('user/penulis/page_homepagePenulis',['data'=>$databuku]);
    }


	public function regtulis() {
		$this->load->view('user/page_header');
		$this->load->view('user/penulis/page_buatakuntulis');
	}

	public function register_tulis() {
        $this->form_validation->set_rules('uname','Uname','required');
        $this->form_validation->set_rules('email','Email','required');
        $this->form_validation->set_rules('pass','Pass','required');
        $this->form_validation->set_rules('tanggal','Tanggal','required');
        if($this->form_validation->run() == FALSE) {
            $this->load->view('user/page_header');
            $this->load->view('user/penulis/page_buatakuntulis');
        } else {
            $uname = $this->input->post("uname");
            $email = $this->input->post("email");
            $cek = $this->M_Home->getPenulis($uname,$email);
            if ($cek == 0) {
                $ceklagi = $this->M_Home->getPembaca($uname,$email);
                if ($ceklagi == 0) {
                    $this->M_Home->tambahPenulis();
                    echo '<script type="text/javascript">alert("Akun berhasil dibuat");</script>';
                    $this->load->view('user/page_header');
                    $this->load->view('user/page_index');
                } else {
                    echo '<script type="text/javascript">alert("Maaf Username/Email telah terpakai");</script>';
                    $this->load->view('user/page_header');
                    $this->load->view('user/page_buatakuntulis');
                }
            } else {
                echo '<script type="text/javascript">alert("Maaf Username/Email telah terpakai");</script>';
                $this->load->view('user/page_header');
                $this->load->view('user/page_buatakuntulis');
            }
        }
    }

}